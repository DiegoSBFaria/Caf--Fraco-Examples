//
//  CafeFracoTests.h
//  CafeFracoTests
//
//  Created by Diego Faria on 17/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CafeFracoTests : SenTestCase

@end
