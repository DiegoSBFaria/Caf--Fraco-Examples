//
//  CafeFracoViewController.m
//  CafeFraco
//
//  Created by Diego Faria on 17/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "CafeFracoViewController.h"

@implementation CafeFracoViewController

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    isFirstClick = YES;
}

- (void)viewDidUnload
{
    if(lblTrocar)
    {
        [lblTrocar release];
        lblTrocar = nil;
    }
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    if(lblTrocar)
        [lblTrocar release];
    [super dealloc];
}

#pragma mark - IBAction para trocar o titulo

- (IBAction)btnTrocarPressed:(id)sender 
{
    if(isFirstClick)
        lblTrocar.text = @"Esse é meu segundo texto de Objective-C";
    else
        lblTrocar.text = @"Acesse o café fraco xD";
    
    isFirstClick = !isFirstClick;
    
}

@end
