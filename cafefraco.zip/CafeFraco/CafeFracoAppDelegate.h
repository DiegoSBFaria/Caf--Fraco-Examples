//
//  CafeFracoAppDelegate.h
//  CafeFraco
//
//  Created by Diego Faria on 17/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CafeFracoViewController;

@interface CafeFracoAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet CafeFracoViewController *viewController;

@end
