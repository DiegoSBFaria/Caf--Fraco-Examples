//
//  CafeFracoViewController.h
//  CafeFraco
//
//  Created by Diego Faria on 17/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CafeFracoViewController : UIViewController
{
    IBOutlet UILabel *lblTrocar;
    BOOL isFirstClick;
}
- (IBAction)btnTrocarPressed:(id)sender;

@end
